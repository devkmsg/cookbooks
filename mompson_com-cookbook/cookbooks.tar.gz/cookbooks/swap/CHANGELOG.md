CHANGELOG for swap
==================
This file is used to list changes made in each version of swap.

0.2.0
-----
- Use fallocate if available - @andrewgross
- Small code restructure

0.1.1
-----
- Fix error in documentation (it's MB, not GB) (@dougal)

0.1.0
-----
- Initial release
