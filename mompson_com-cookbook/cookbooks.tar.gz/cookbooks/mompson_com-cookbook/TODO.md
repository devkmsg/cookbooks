  * When the hostname changes
    * The bind-address is incorrect so chef connot start mysqld
    * The mysql grants break because chef cannot update the mysql grants
