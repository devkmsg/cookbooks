name             "mompson_com-cookbook"
maintainer       "Andrew Thompson"
maintainer_email "netengr2009@gmail.com"
license          "All rights reserved"
description      "Installs/Configures mompson_com-cookbook"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.1.2"

depends 'wordpress', '>= 1.0.0'
depends 'swap'
