#
# Cookbook Name:: mompson_com-cookbook
# Recipe:: default
#
# Copyright (C) 2013 YOUR_NAME
# 
# All rights reserved - Do Not Redistribute
#

include_recipe 'wordpress::default'

user 'wp-uploader' do
  uid 1000
  gid 'apache'
  password '$1$XuB2Qg0f$H8qrfPuoDKgxcVKyBABzH1'
end

execute "fixup /var/www/wordpress ownership" do
  command "chown -Rf apache:apache /var/www/wordpress"
end

package 'php-xml' do # Required for the WP Importer
  notifies :restart, "service[apache2]", :delayed
end

package 'gcc'
package 'libxml2'
package 'libxml2-devel'
package 'libxslt'
package 'libxslt-devel'
package 'ruby19'
package 'ruby19-devel'

link '/usr/bin/ruby' do
    to '/usr/bin/ruby1.9'
end

gem_package 'berkshelf'

directory '/usr/local/cron/'
cookbook_file '/usr/local/cron/build_recipes.sh' do
  source 'build_recipes.sh'
  mode 0700
  owner 'root'
  group 'root'
end

cron 'build_recipes' do
  action :delete
  minute '*/30'
  hour '*'
  weekday '*'
  user 'root'
  command '/usr/local/cron/build_recipes.sh'
end

template '/etc/chef/solo.rb' do
  source 'solo.rb.erb'
  mode 0644
  owner 'root'
  group 'root'
  variables({
     :recipe_url => default['mompson_com-cookbook']['recipe_url']
  })
end

#swap_file '/mnt/swap' do
#  size 2048 # MBs
#end
