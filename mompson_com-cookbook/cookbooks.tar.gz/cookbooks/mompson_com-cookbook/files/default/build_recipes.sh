#!/bin/bash

ARCHIVE=/tmp/mompson_com-cookbook.tar.gz
COOKBOOK_DIR=/var/chef/cookbooks

lockfile $0.lock

if [[ -f $ARCHIVE ]]; then
    rm $ARCHIVE
fi

if [[ -d $COOKBOOK_DIR ]]; then
    rm -r $COOKBOOK_DIR
fi

curl -L https://api.github.com/repos/netengr2009/mompson_com-cookbook/tarball > $ARCHIVE
cd /tmp && tar -xzf mompson_com-cookbook.tar.gz

if [[ -d "mompson_com-cookbook" ]]; then
    rm -r mompson_com-cookbook
fi

mv netengr2009-mompson_com-cookbook-* mompson_com-cookbook
cd /tmp/mompson_com-cookbook
/usr/local/bin/berks install --path=/var/chef/cookbooks
/usr/bin/chef-solo -j /etc/chef/node.json -L /var/log/chef-solo.log -l info

rm -f $0.lock
