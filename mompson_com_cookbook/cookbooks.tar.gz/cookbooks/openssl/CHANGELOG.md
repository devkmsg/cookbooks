## v1.0.2:

* Add name attribute to metadata
