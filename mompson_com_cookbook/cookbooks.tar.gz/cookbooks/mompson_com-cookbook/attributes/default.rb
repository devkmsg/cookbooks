default['wordpress']['db']['database'] = 'mompson_com_prod'
default['wordpress']['db']['user'] = 'mompson_com_prod'
default['wordpress']['db']['password'] = '9b84fcdc3c0fdac1f39bed469a382fd1'
default['wordpress']['server_aliases'] = ['mompson.com']

#Apache Tuning
default['apache']['timeout'] = '40'
default['apache']['keepaliverequests'] = '200'
default['apache']['keepalivetimeout'] = '2'
default['apache']['prefork']['startservers'] = '5'
default['apache']['prefork']['minspareservers'] = '5'
default['apache']['prefork']['maxspareservers'] = '10'
default['apache']['prefork']['serverlimit'] = '35'
default['apache']['prefork']['maxclients'] = '35'
default['apache']['prefork']['maxrequestsperchild'] = '10000'

#MySQL Tuning
default['mysql']['tunable']['key_buffer_size'] = '5M'
default['mysql']['tunable']['tmp_table_size'] = '512K'
default['mysql']['tunable']['sort_buffer_size'] = '256K'
default['mysql']['tunable']['innodb_buffer_pool_size'] = '5M'
default['mysql']['tunable']['innodb_buffer_pool_instances'] = '1'
default['mysql']['tunable']['innodb_io_capacity'] = '100'
default['mysql']['tunable']['query_cache_size'] = '6M'
